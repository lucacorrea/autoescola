<?php

$servername = "localhost";
$username = "cfcaut82_autoescola";
$password = "Bt~fC13X5k{l";
$dbname = "cfcaut82_autoescola";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Falha na conex���o: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");


?>
