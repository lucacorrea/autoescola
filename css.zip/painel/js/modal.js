function openModal() {
    var modal = document.getElementById('confirmDeleteHorarioModal');
    modal.style.display = 'block';
}

function closeModal() {
    var modal = document.getElementById('confirmDeleteHorarioModal');
    modal.style.display = 'none';
}
