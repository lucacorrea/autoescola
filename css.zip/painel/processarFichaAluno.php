<?php
session_start(); // Iniciar a sessão

// Função para verificar se o usuário está logado (admin ou presidente)
function verificarAcesso() {
    if (isset($_SESSION['id_usuario']) && isset($_SESSION['nivel'])) {
        $nivel_usuario = $_SESSION['nivel'];
        if ($nivel_usuario == 'admin' || $nivel_usuario == 'presidente' || $nivel_usuario == 'suporte') {
            return true;
        }
    }
    header("Location: loader.php");
    exit();
}

verificarAcesso();

include "conexao.php";

// Obter os dados do formulário
$nome = $_POST['nome'] ?? '';
$rg = $_POST['rg'] ?? '';
$cpf = $_POST['cpf'] ?? '';
$ladv = isset($_POST['ladv']) ? date('Y-m-d', strtotime($_POST['ladv'])) : '';
$vencimento_processo = isset($_POST['vencimento_processo']) ? date('Y-m-d', strtotime($_POST['vencimento_processo'])) : '';
$categoria = $_POST['categoria'] ?? '';
$instrutor = $_POST['instrutor'] ?? '';
$placa = $_POST['placa'] ?? '';
$registro = $_POST['registro'] ?? '';
$horario_inicio = $_POST['horario_inicio'] ?? '';
$horario_fim = $_POST['horario_fim'] ?? '';
$data_ficha = isset($_POST['data_ficha']) ? date('Y-m-d', strtotime($_POST['data_ficha'])) : '';
$id_aluno = isset($_POST['id_aluno']) ? (int)$_POST['id_aluno'] : 0;

// Armazena os dados do formulário na sessão para reutilização
$_SESSION['form_data'] = [
    'nome' => $nome,
    'rg' => $rg,
    'cpf' => $cpf,
    'ladv' => $ladv,
    'vencimento_processo' => $vencimento_processo,
    'categoria' => $categoria,
    'instrutor' => $instrutor,
    'placa' => $placa,
    'registro' => $registro,
    'horario_inicio' => $horario_inicio,
    'horario_fim' => $horario_fim,
    'data_ficha' => $data_ficha,
    'id_aluno' => $id_aluno
];

// Chama a função de verificação de aulas apenas para as categorias permitidas
if (in_array($categoria, ['A', 'B', 'AB', 'D'])) {
    if (!verificarCategorias($conn, $categoria, $rg, $_POST['horario_inicio'], $_POST['horario_fim'])) {
        // Liberando os recursos da conexão PDO
        $conn = null;
        echo "<script>window.location.href='criarFicha.php?id={$id_aluno}';</script>";
        exit();
    }
}

function verificarCategorias($conn, $categoria, $rg, $horario_inicio, $horario_fim) {
    // Calcular as horas da nova aula
    $nova_hora_inicio = strtotime($horario_inicio);
    $nova_hora_fim = strtotime($horario_fim);
    $nova_hora_total = ($nova_hora_fim - $nova_hora_inicio) / 3600; // Converter para horas

    // Verifica se a nova hora total é válida
    if ($nova_hora_total <= 0) {
        echo "<script>alert('Horário de fim deve ser maior que o horário de início.');</script>";
        return false;
    }

    // Contar quantas aulas e horas já foram cadastradas para a categoria e para o aluno
    $query_categoria = "
        SELECT COALESCE(SUM(TIMESTAMPDIFF(SECOND, horario_inicio, horario_fim)) / 3600, 0) AS total_horas 
        FROM fichas 
        WHERE categoria = :categoria AND rg = :rg";

    // Preparar a consulta
    $stmt = $conn->prepare($query_categoria);

    // Verificar se a preparação da consulta foi bem-sucedida
    if (!$stmt) {
        echo "<script>alert('Erro ao preparar a consulta.');</script>";
        return false;
    }

    // Vincular os parâmetros à consulta PDO
    $stmt->bindParam(':categoria', $categoria, PDO::PARAM_STR);
    $stmt->bindParam(':rg', $rg, PDO::PARAM_STR);

    // Executar a consulta
    $stmt->execute();

    // Obter o resultado
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row === false) {
        echo "<script>alert('Erro ao obter total de aulas.');</script>";
        return false;
    }

    // Total de horas já cadastradas
    $total_horas = $row['total_horas'] ?? 0; // Usa zero se não houver horas

    // Calcular o total de horas incluindo a nova aula
    $total_horas += $nova_hora_total;

    // Verifica se o total de horas é diferente de 20
    if ($total_horas > 20) {
        echo "<script>alert('O total de horas para a categoria {$categoria} deve ser exatamente 20 horas.');</script>";
        return false;
    }

    return true;
}


// Chama a função de verificação de aulas apenas para as categorias permitidas
if (in_array($categoria, ['A/AB', 'B/AB', 'A/D'])) {
    if (!verificarAulas($conn, $categoria, $rg, $_POST['horario_inicio'], $_POST['horario_fim'])) {
        // Liberar a conexão PDO (não é necessário fechar explicitamente, mas você pode definir como null)
        $conn = null;
        echo "<script>window.location.href='criarFicha.php?id={$id_aluno}';</script>";
        exit();
    }
}


function verificarAulas($conn, $categoria, $rg, $horario_inicio, $horario_fim) {
    // Calcular as horas da nova aula
    $nova_hora_inicio = strtotime($horario_inicio);
    $nova_hora_fim = strtotime($horario_fim);
    $nova_hora_total = ($nova_hora_fim - $nova_hora_inicio) / 3600; // Converter para horas

    // Verifica se a nova hora total é válida
    if ($nova_hora_total <= 0) {
        echo "<script>alert('Horário de fim deve ser maior que o horário de início.');</script>";
        return false;
    }

    // Contar quantas aulas e horas já foram cadastradas para a categoria e para o aluno
    $query_categoria = "
        SELECT COALESCE(SUM(TIMESTAMPDIFF(SECOND, horario_inicio, horario_fim)) / 3600, 0) AS total_horas 
        FROM fichas 
        WHERE categoria = :categoria AND rg = :rg";

    // Preparar a consulta
    $stmt = $conn->prepare($query_categoria);
    
    // Verificar se a preparação da consulta foi bem-sucedida
    if (!$stmt) {
        echo "<script>alert('Erro ao preparar a consulta.');</script>";
        return false;
    }

    // Vincular os parâmetros à consulta PDO
    $stmt->bindParam(':categoria', $categoria, PDO::PARAM_STR);
    $stmt->bindParam(':rg', $rg, PDO::PARAM_STR);

    // Executar a consulta
    $stmt->execute();

    // Obter o resultado
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row === false) {
        echo "<script>alert('Erro ao obter total de aulas.');</script>";
        return false;
    }

    // Total de horas já cadastradas
    $total_horas = $row['total_horas'] ?? 0; // Usa zero se não houver horas

    // Calcular o total de horas incluindo a nova aula
    $total_horas += $nova_hora_total;

    // Verifica se o total de horas é diferente de 15
    if ($total_horas > 15) {
        echo "<script>alert('O total de horas para a categoria {$categoria} deve ser exatamente 15 horas.');</script>";
        return false;
    }

    return true;
}


// Verifica se a data selecionada é um domingo
if (date('w', strtotime($data_ficha)) == 0) { // 0 representa domingo
    // Liberar a conexão PDO (não é necessário fechar explicitamente)
    $conn = null;
    echo "<script>alert('A data selecionada cai em um domingo. Não é possível cadastrar a ficha.'); window.location.href='criarFicha.php?id={$id_aluno}';</script>";
    exit();
}


// Verificar se a data_ficha é um feriado
$query_feriado = "SELECT COUNT(*) AS count FROM feriados WHERE data = :data_ficha";
$stmt = $conn->prepare($query_feriado);

// Vincular o parâmetro
$stmt->bindParam(':data_ficha', $data_ficha, PDO::PARAM_STR);

// Executar a consulta
$stmt->execute();

// Obter o resultado
$feriado = $stmt->fetch(PDO::FETCH_ASSOC);

// Liberar a consulta (opcional, o PDO gerencia automaticamente)
$stmt = null;

// Verificar se a data é um feriado
if ($feriado['count'] > 0) {
    echo "<script>alert('A data informada é um feriado. Não é possível cadastrar a ficha.'); window.location.href='criarFicha.php?id={$id_aluno}';</script>";
    exit();
}


// Verificar se já existe um registro com o mesmo instrutor, placa, data e intervalo de horário que se sobrepõe
$query_verifica = "
    SELECT id FROM fichas 
    WHERE instrutor = :instrutor 
    AND placa = :placa 
    AND data_ficha = :data_ficha
    AND (
        (horario_inicio <= :horario_inicio AND horario_fim > :horario_inicio) OR
        (horario_inicio < :horario_fim AND horario_fim >= :horario_fim) OR
        (horario_inicio >= :horario_inicio AND horario_fim <= :horario_fim)
    )";

$stmt = $conn->prepare($query_verifica);

// Vincular os parâmetros
$stmt->bindParam(':instrutor', $instrutor, PDO::PARAM_STR);
$stmt->bindParam(':placa', $placa, PDO::PARAM_STR);
$stmt->bindParam(':data_ficha', $data_ficha, PDO::PARAM_STR);
$stmt->bindParam(':horario_inicio', $horario_inicio, PDO::PARAM_STR);
$stmt->bindParam(':horario_fim', $horario_fim, PDO::PARAM_STR);

// Executar a consulta
$stmt->execute();

// Obter o resultado
$verifica = $stmt->fetch(PDO::FETCH_ASSOC);

// Liberar a consulta (opcional, o PDO gerencia automaticamente)
$stmt = null;

// Verificar se há um resultado
if ($verifica) {
    echo "<script>alert('Já existe uma ficha cadastrada com o mesmo instrutor, placa, horário e data que entra em conflito com este horário.'); window.location.href='criarFicha.php?id={$id_aluno}';</script>";
    exit();
}


// Verificar se já existe um registro com o mesmo instrutor, placa, horário e data
$query_verifica = "SELECT id FROM fichas WHERE instrutor = :instrutor AND placa = :placa AND horario_inicio = :horario_inicio AND horario_fim = :horario_fim AND data_ficha = :data_ficha";
$stmt = $conn->prepare($query_verifica);
$stmt->bindParam(':instrutor', $instrutor);
$stmt->bindParam(':placa', $placa);
$stmt->bindParam(':horario_inicio', $horario_inicio);
$stmt->bindParam(':horario_fim', $horario_fim);
$stmt->bindParam(':data_ficha', $data_ficha);
$stmt->execute();
$verifica = $stmt->fetch();

if ($verifica) {
    $conn = null;
    echo "<script>alert('Já existe uma ficha cadastrada com o mesmo instrutor, placa, horário e data.'); window.location.href='criarFicha.php?id={$id_aluno}';</script>";
    exit();
}


// Verificar se já existe um registro com a mesma placa, data_ficha, horário_inicio e horário_fim (independentemente do instrutor)
$query_verifica_placa = "SELECT id FROM fichas WHERE placa = :placa AND horario_inicio = :horario_inicio AND horario_fim = :horario_fim AND data_ficha = :data_ficha";
$stmt = $conn->prepare($query_verifica_placa);
$stmt->bindParam(':placa', $placa);
$stmt->bindParam(':horario_inicio', $horario_inicio);
$stmt->bindParam(':horario_fim', $horario_fim);
$stmt->bindParam(':data_ficha', $data_ficha);
$stmt->execute();
$verifica_placa = $stmt->fetch();

if ($verifica_placa) {
    $conn = null;
    echo "<script>alert('Já existe uma ficha cadastrada com a mesma placa, horário e data com outro instrutor ou aluno.'); window.location.href='criarFicha.php?id={$id_aluno}';</script>";
    exit();
}


// Verificar se já existe um registro com o mesmo instrutor, na mesma data e horário
$query_verifica_instrutor_horario = "SELECT id FROM fichas WHERE instrutor = :instrutor AND data_ficha = :data_ficha AND (
    (horario_inicio <= :horario_inicio AND horario_fim >= :horario_inicio) OR
    (horario_inicio <= :horario_fim AND horario_fim >= :horario_fim)
)";
$stmt = $conn->prepare($query_verifica_instrutor_horario);
$stmt->bindParam(':instrutor', $instrutor);
$stmt->bindParam(':data_ficha', $data_ficha);
$stmt->bindParam(':horario_inicio', $horario_inicio);
$stmt->bindParam(':horario_fim', $horario_fim);
$stmt->execute();
$verifica_instrutor_horario = $stmt->fetch();

if ($verifica_instrutor_horario) {
    $conn = null;
    echo "<script>alert('Conflito de horário: O instrutor já tem uma ficha cadastrada para esse horário e data.'); window.location.href='criarFicha.php?id={$id_aluno}';</script>";
    exit();
}

// Inserir a ficha
$query_inserir = "INSERT INTO fichas (nome, rg, cpf, ladv, vencimento_processo, categoria, instrutor, placa, registro, horario_inicio, horario_fim, data_ficha, status)
                  VALUES (:nome, :rg, :cpf, :ladv, :vencimento_processo, :categoria, :instrutor, :placa, :registro, :horario_inicio, :horario_fim, :data_ficha, 'Em Andamento')";
$stmt = $conn->prepare($query_inserir);
$stmt->bindParam(':nome', $nome);
$stmt->bindParam(':rg', $rg);
$stmt->bindParam(':cpf', $cpf);
$stmt->bindParam(':ladv', $ladv);
$stmt->bindParam(':vencimento_processo', $vencimento_processo);
$stmt->bindParam(':categoria', $categoria);
$stmt->bindParam(':instrutor', $instrutor);
$stmt->bindParam(':placa', $placa);
$stmt->bindParam(':registro', $registro);
$stmt->bindParam(':horario_inicio', $horario_inicio);
$stmt->bindParam(':horario_fim', $horario_fim);
$stmt->bindParam(':data_ficha', $data_ficha);

if ($stmt->execute()) {
    echo "<script>alert('Ficha cadastrada com sucesso.'); window.location.href='criarFicha.php?id={$id_aluno}';</script>";
} else {
    echo "<script>alert('Erro ao cadastrar ficha: " . $stmt->errorInfo()[2] . "'); window.location.href='criarFicha.php?id={$id_aluno}';</script>";
}

$stmt = null;
$conn = null;

?>